using Infiltrator

function ConsToPrims!(P, U)
    P[1] = U[1];
    P[2] = U[2] / U[1];
    P[3] = (U[3] - 0.5 * (P[2]^2)) / Cp
    P[4] = P[1] * R * P[3]
end

function PrimsToCons!(U, P)
    U[1] = P[1]
    U[2] = P[1] * P[2]
    U[3] = 0.5 * P[2]^2 + Cp * P[3]
end

function FDUpdate!(dU, U, P)
    @. @views dU[1, 2:end-1] = -(P[2, 2:end-1] * (U[1, 3:end] - U[1, 1:end-2]) / Δx)
    @. @views dU[2, 2:end-1] = -(P[2, 2:end-1] * (U[2, 3:end] - U[2, 1:end-2]) / Δx + (P[4, 3:end] - P[4, 1:end-2]) / Δx)
    @. @views dU[3, 2:end-1] = -(P[2, 2:end-1] * (U[3, 3:end] - U[3, 1:end-2]) / Δx)
end

function TakeSteps(P₀, U₀, Steps)
    dU = zero(U₀)
    for Step = 1:Steps
        # Demonstrate the infiltrate tool- can add a boolean clause like
        # @infiltrate Step % 10 to infiltrate every 10 steps
        @infiltrate
        FDUpdate!(dU, U₀, P₀)
        U₀ += dU
        for indx = 1:1000000
            ConsToPrims!(@view(P[:, indx]), @view(U[:, indx]))
        end
    end
end
